# EEG-CogState

Système intelligent de classification des états cognitifs à partir de signaux EEG et de Machine Learning.

> **Avancement : Sprint 3 terminé** — extraction de features (bandes, ratios, statistiques)

---

## Description

EEG-CogState analyse des signaux EEG pour estimer l'état cognitif d'un utilisateur (concentration, relaxation, etc.). Le projet couvre toute la chaîne : import des données, prétraitement, extraction de features, classification et visualisation.

**Dataset utilisé** : STEW — Simultaneous Task EEG Workload (48 sujets, 14 canaux, 128 Hz).
https://ieee-dataport.org/open-access/stew-simultaneous-task-eeg-workload-dataset

---

## Installation

```bash
cd EEG-CogState

python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate     # macOS / Linux

pip install -r requirements.txt
```

---

## Obtenir les données

1. Téléchargez le dataset STEW depuis IEEE DataPort (gratuit pour les membres IEEE).
2. Placez les fichiers `.txt` (`sub01_lo.txt`, `sub01_hi.txt`, …) dans `data/raw/`.

Convention de nommage STEW :
- `subXX_lo.txt` -> repos (étiquette : relaxation)
- `subXX_hi.txt` -> multitâche (étiquette : concentration)

> Les fichiers de données ne sont pas versionnés (voir `.gitignore`).

---

## Utilisation (Sprint 1)

**Option A — Notebook (recommandé)**

```bash
jupyter notebook notebooks/01_exploration.ipynb   # Sprint 1 : exploration
jupyter notebook notebooks/02_preprocessing.ipynb # Sprint 2 : prétraitement
jupyter notebook notebooks/03_features.ipynb      # Sprint 3 : features
```

**Option B — Ligne de commande**

```bash
python src/config.py     # vérifie la configuration
python src/io_eeg.py     # liste les fichiers de data/raw/
python src/viz.py        # génère les figures dans results/
```

---

## Structure du projet

```
EEG-CogState/
├── data/
│   ├── raw/              # fichiers STEW bruts (.txt) — à déposer ici
│   └── processed/        # données nettoyées (Sprint 2+)
├── notebooks/
│   └── 01_exploration.ipynb
├── src/
│   ├── config.py         # paramètres centralisés
│   ├── io_eeg.py         # lecture des fichiers EEG
│   └── viz.py            # visualisation (signaux, PSD)
├── results/              # figures générées
├── models/               # modèles entraînés (Sprint 4+)
├── requirements.txt
└── README.md
```

---

## Feuille de route

| Sprint | Objectif | Statut |
|--------|----------|--------|
| 1 | Socle EEG : chargement + visualisation | Termine |
| 2 | Prétraitement : filtrage, notch, epoching | Termine |
| 3 | Features : PSD, bandes, ratios, entropie | Termine |
| 4 | Machine learning : Random Forest, validation par sujet | À venir |
| 5 | Application web Streamlit | À venir |
| 6 | Finalisation : dashboard, tests, doc | À venir |

---

## Note méthodologique importante

Lors de la phase ML (Sprint 4), la validation se fera **par sujet** (Leave-One-Subject-Out), jamais par segment. Répartir aléatoirement les epochs d'un même sujet entre entraînement et test crée une fuite de données qui gonfle artificiellement les scores et masque la capacité réelle de généralisation à un nouvel utilisateur.
